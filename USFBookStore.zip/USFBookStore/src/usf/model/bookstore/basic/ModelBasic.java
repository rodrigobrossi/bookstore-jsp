package usf.model.bookstore.basic;

public interface ModelBasic {

	public int getId();
}
